package br.com.carlosjunior.registrationlogin.services;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import br.com.carlosjunior.registrationlogin.entities.User;
import br.com.carlosjunior.registrationlogin.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService{
	 List<User> getUser();
	User save(UserRegistrationDto registrationDto);
	
}
