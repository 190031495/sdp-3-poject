package br.com.carlosjunior.registrationlogin.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import br.com.carlosjunior.registrationlogin.entities.User;
import br.com.carlosjunior.registrationlogin.services.UserService;

@Controller
public class MainController {

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	 
	@GetMapping("/home")
	public String mkmkm(Model model)
	{
		return "home";
	}
	@GetMapping("/")
	public String mkgh(Model model)
	{
		return "yash";
	}
	
	@GetMapping("/south")
	public String mkkgh(Model model)
	{
		return "south";
	}

	@GetMapping("/east")
	public String mkkagh(Model model)
	{
		return "east";
	}
	@GetMapping("/west")
	public String mkkaghk(Model model)
	{
		return "west";
	}
	
	@GetMapping("/north")
	public String mkgkdjh(Model model)
	{
		return "north";
	}
	@GetMapping("/tirupathi")
	public String mkgkdjfh(Model model)
	{
		return "tirupathi";
	}
	
	@GetMapping("/Hyderabad")
	public String mkgkdjhy(Model model)
	{
		return "Hyderabad";
	}
	@GetMapping("/tajmahal")
	public String mkgkdjhfy(Model model)
	{
		return "tajmahal";
	}
	
	@GetMapping("/madurai")
	public String mkgkjdh(Model model)
	{
		return "madurai";
	}
	@GetMapping("/redfort")
	public String mkgkjdhf(Model model)
	{
		return "Red Fort";
	}
	@GetMapping("/mysorepalace")
	public String mkgkjdhjf(Model model)
	{
		return "mysorepalace";
	}
	@GetMapping("/Aga Khan Palace Building")
	public String mkgkjjf(Model model)
	{
		return "Aga Khan Palace Building";
	}
	@GetMapping("/Bhaja Caves")
	public String mkgkjf(Model model)
	{
		return "Bhaja Caves";
	}
	@GetMapping("/thank")
	public String mkgkjkjf(Model model)
	{
		return "thank";
	}
	@GetMapping("/adminlogin")
	public String mkgkff(Model model)
	{
		return "adminlogin";
	}
	
	
	@Autowired
	  private UserService userServiceImpl;
	  
	  
	  @GetMapping("/admin")
	  public String getAdminext(Model model) {
	    
	    List<User> userList = userServiceImpl.getUser();
	    
	    model.addAttribute("admin", userList);
	    
	    
	    return "admin";
	  }
	
	
	@GetMapping("/GOLDENTEMPLE")
	public String mKkgkf(Model model)
	{
		return "GOLDENTEMPLE";
	}
	@GetMapping("/hawamahal")
	public String mkgkf(Model model)
	{
		return "Hawa Mahal";
	}
	@GetMapping("/Cooch Behar")
	public String mkgkfg(Model model)
	{
		return "Cooch Behar";
	}
	
	@GetMapping("/Konarkk")
	public String mfg(Model model)
	{
		return "Konarkk";
	}
	@GetMapping("/mauryan")
	public String mmfg(Model model)
	{
		return "site of Mauryan palace";
	}
	@GetMapping("/anjanta")
	public String mmfgg(Model model)
	{
		return "Ajanta Caves";
	}
	@GetMapping("/kanheri")
	public String mmfhyg(Model model)
	{
		return "Kanheri Caves";
	}
	@GetMapping("/museum")
	public String mmfghg(Model model)
	{
		return "Archaeological Museum";
	}
	
	@GetMapping("/contactus")
	public String mkgkh(Model model)
	{
		return "contactus";
	}
	@GetMapping("/sdphome")
	public String mkgkhcs(Model model)
	{
		return "sdphome";
	}
	
	@GetMapping("/yash")
	public String yass(Model model)
	{
		return "yash";
	}
	@GetMapping("/northstyle")
	public String yassh(Model model)
	{
		return "northstyle";
	}
	@GetMapping("/weststyle")
	public String yasshh(Model model)
	{
		return "weststyle";
	}
	@GetMapping("/southstyle")
	public String yasshhh(Model model)
	{
		return "southstyle";
	}
	@GetMapping("/eaststyle")
	public String yasshhhh(Model model)
	{
		return "eaststyle";
	}


}
