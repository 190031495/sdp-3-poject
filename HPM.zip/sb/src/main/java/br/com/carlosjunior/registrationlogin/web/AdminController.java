package br.com.carlosjunior.registrationlogin.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import br.com.carlosjunior.registrationlogin.entities.User;
import br.com.carlosjunior.registrationlogin.services.UserService;
import br.com.carlosjunior.registrationlogin.services.UserServiceImpl;


@Controller
public class AdminController {
/*	@Autowired
	  private UserService userServiceImpl;
	  
	  
	  @GetMapping("/admin")
	  public String getAdminext(Model model) {
	    
	    List<User> userList = userServiceImpl.getUser();
	    
	    model.addAttribute("admin", userList);
	    
	    
	    return "admin";
	  }*/
}
