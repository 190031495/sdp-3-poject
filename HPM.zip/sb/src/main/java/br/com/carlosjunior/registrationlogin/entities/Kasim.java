package br.com.carlosjunior.registrationlogin.entities;

import javax.persistence.*;

@Entity
@Table(name="kasim")
public class Kasim 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long Id;
	
	@Column(name="fname")
	private String fname;
	
	@Column(name="lname")
	private String lname;
	
	@Column(name="issue")
	private String issue;
	
	@Column(name="sub")
	private String sub;

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getIssue() {
		return issue;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}

	public String getSub() {
		return sub;
	}

	public void setSub(String sub) {
		this.sub = sub;
	}

	public Kasim(Long id, String fname, String lname, String issue, String sub) {
		super();
		Id = id;
		this.fname = fname;
		this.lname = lname;
		this.issue = issue;
		this.sub = sub;
	}
	
	public Kasim()
	{
		
	}

}
